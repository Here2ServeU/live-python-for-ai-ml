# Python for AI-ML (T2S AI-ML Membership)

Course repo for the 3-module **Python for AI-ML** course. One dataset, three scripts, one pipeline:

    raw CSV  ->  inspect (Module 1)  ->  model (Module 2)  ->  LLM summary (Module 3)

## Setup
    python3 -m venv .venv && source .venv/bin/activate     # Windows: py -m venv .venv; .venv\Scripts\Activate.ps1
    pip install -r requirements.txt

Run every command from the repo root.

| Module | Command |
|---|---|
| 1 | `python3 modules/module-1/scripts/inspect_data.py` |
| 2 | `python3 modules/module-2/scripts/train.py` |
| 3 | `python3 modules/module-3/scripts/explain.py --offline` (no key) or without `--offline` (real call) |

Regenerate the dataset any time: `python3 data/make_data.py`
