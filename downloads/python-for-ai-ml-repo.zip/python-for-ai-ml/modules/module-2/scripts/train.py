"""Module 2: clean the data, split honestly, train two models, score them."""
import argparse, json
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split

p = argparse.ArgumentParser()
p.add_argument("--input", default="data/transactions.csv")
p.add_argument("--out", default="metrics.json")
args = p.parse_args()

df = pd.read_csv(args.input)
print("loaded", len(df), "rows;", int(df["amount"].isna().sum()), "missing amounts")
df = df.dropna(subset=["amount"])
X = pd.get_dummies(df[["amount", "hour", "merchant"]], columns=["merchant"])
y = df["is_fraud"]

X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
print(len(X_tr), "train rows ·", len(X_te), "test rows")

baseline = [0] * len(y_te)  # a "model" that always says not fraud
results = {"always_not_fraud": {
    "accuracy": round(accuracy_score(y_te, baseline), 3),
    "f1": round(f1_score(y_te, baseline, zero_division=0), 3)}}

models = {
    "logistic_regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
    "random_forest": RandomForestClassifier(
        n_estimators=200, class_weight="balanced", min_samples_leaf=5, random_state=42),
}
for name, m in models.items():
    m.fit(X_tr, y_tr)
    pred = m.predict(X_te)
    results[name] = {"accuracy": round(accuracy_score(y_te, pred), 3),
                     "f1": round(f1_score(y_te, pred), 3)}

for name, r in results.items():
    print(f"{name:22} accuracy {r['accuracy']:.3f}   f1 {r['f1']:.3f}")
json.dump({"test_rows": len(y_te), "fraud_in_test": int(y_te.sum()), "models": results},
          open(args.out, "w"), indent=2)
print(f"saved -> {args.out}")
