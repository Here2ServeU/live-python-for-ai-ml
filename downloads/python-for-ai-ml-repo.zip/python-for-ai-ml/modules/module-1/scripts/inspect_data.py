"""Module 1: inspect a CSV with nothing but the standard library."""
import argparse, csv, json, sys


def load_rows(path):
    """Read a CSV into a list of dicts. Fail loudly and clearly."""
    try:
        with open(path, newline="") as f:
            return list(csv.DictReader(f))
    except FileNotFoundError:
        sys.exit(f"error: {path} not found. Are you in the repo root?")


def summarize(rows):
    missing = sum(1 for r in rows if r["amount"] == "")
    fraud = [r for r in rows if r["is_fraud"] == "1"]
    by_merchant = {}
    for r in rows:
        m = r["merchant"]
        by_merchant.setdefault(m, [0, 0])
        by_merchant[m][0] += 1
        by_merchant[m][1] += int(r["is_fraud"])
    return {
        "rows": len(rows),
        "missing_amount": missing,
        "fraud_rows": len(fraud),
        "fraud_rate_pct": round(100 * len(fraud) / len(rows), 2),
        "fraud_rate_by_merchant_pct": {
            m: round(100 * f / n, 2) for m, (n, f) in sorted(by_merchant.items())
        },
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--input", default="data/transactions.csv")
    p.add_argument("--out", default="summary.json")
    args = p.parse_args()

    s = summarize(load_rows(args.input))
    for k, v in s.items():
        print(f"{k:28} {v}")
    with open(args.out, "w") as f:
        json.dump(s, f, indent=2)
    print(f"saved -> {args.out}")
