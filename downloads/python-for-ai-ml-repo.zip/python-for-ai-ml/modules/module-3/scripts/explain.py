"""Module 3: send model results to an LLM and get a plain-language summary.

--offline uses a simulated reply so you can run it with no API key and no cost.
"""
import argparse, json, os, sys, time

PROMPT = """You are explaining a fraud model to a non-technical manager.
Results on {test_rows} held-out transactions ({fraud_in_test} were fraud):
{table}
In 4 short sentences: which model to trust, why accuracy is misleading here,
and one next step. No jargon."""


def build_prompt(metrics):
    table = "\n".join(f"- {n}: accuracy {r['accuracy']}, F1 {r['f1']}"
                      for n, r in metrics["models"].items())
    return PROMPT.format(table=table, **metrics)


def call_llm(prompt, model, max_tokens, retries=3):
    import anthropic
    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from the environment
    for attempt in range(1, retries + 1):
        try:
            msg = client.messages.create(model=model, max_tokens=max_tokens,
                                         messages=[{"role": "user", "content": prompt}])
            return msg.content[0].text, msg.usage.input_tokens, msg.usage.output_tokens
        except (anthropic.RateLimitError, anthropic.APIConnectionError) as e:
            wait = 2 ** attempt
            print(f"attempt {attempt} failed ({type(e).__name__}); retrying in {wait}s")
            time.sleep(wait)
    sys.exit("error: gave up after retries")


def fake_llm(prompt, max_tokens, metrics):
    best = max(metrics["models"], key=lambda n: metrics["models"][n]["f1"])
    text = (f"Trust the {best.replace('_', ' ')}: it has the highest F1, so it catches the "
            "most real fraud. Accuracy looks great for every model because almost nothing "
            "is fraud, so a model that never flags anything still scores high. F1 only rises "
            "when real fraud is caught. Next step: test it on last month's data before going live.")
    return text, len(prompt) // 4, min(len(text) // 4, max_tokens)  # ~4 chars per token


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--metrics", default="metrics.json")
    p.add_argument("--model", default="claude-sonnet-4-5")
    p.add_argument("--max-tokens", type=int, default=300)
    p.add_argument("--input-rate", type=float, default=3.00, help="$ per million input tokens")
    p.add_argument("--output-rate", type=float, default=15.00, help="$ per million output tokens")
    p.add_argument("--offline", action="store_true", help="simulated reply, no key, no cost")
    args = p.parse_args()

    metrics = json.load(open(args.metrics))
    prompt = build_prompt(metrics)
    if args.offline:
        text, tin, tout = fake_llm(prompt, args.max_tokens, metrics)
    else:
        if not os.environ.get("ANTHROPIC_API_KEY"):
            sys.exit("error: ANTHROPIC_API_KEY is not set (or run with --offline)")
        text, tin, tout = call_llm(prompt, args.model, args.max_tokens)

    cost = tin / 1e6 * args.input_rate + tout / 1e6 * args.output_rate
    print(text, "\n")
    print(f"usage: input_tokens={tin} output_tokens={tout} · cost ${cost:.5f}"
          + ("  (offline estimate)" if args.offline else ""))
    open("summary.md", "w").write(text + "\n")
    print("saved -> summary.md")
