"""Generate the course dataset: data/transactions.csv (deterministic, seed 42)."""
import csv, random

random.seed(42)
MERCHANTS = ["grocery", "fuel", "online", "travel", "electronics"]
rows = []
for i in range(5000):
    merchant = random.choice(MERCHANTS)
    hour = random.randint(0, 23)
    amount = round(random.lognormvariate(3.5, 1.0), 2)
    risk = 0.002
    if merchant in ("online", "electronics"): risk += 0.02
    if hour < 5: risk += 0.08
    is_fraud = 1 if random.random() < risk else 0
    if is_fraud: amount = round(amount * random.uniform(4, 10), 2)
    # a few messy values, like real data
    amount_out = "" if random.random() < 0.02 else amount
    rows.append({"txn_id": f"T{i:05d}", "amount": amount_out, "merchant": merchant,
                 "hour": hour, "is_fraud": is_fraud})

with open("data/transactions.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys())
    w.writeheader(); w.writerows(rows)
print(f"wrote {len(rows)} rows to data/transactions.csv")
